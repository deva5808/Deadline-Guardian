# BlockseBlock Submission Steps

Use these steps after you deploy the app and upload the repository.

## 1. Deploy the app

Deploy through Google AI Studio Build Mode and copy the generated Cloud Run application URL.

Official reference: https://ai.google.dev/gemini-api/docs/aistudio-deploying

## 2. Upload source code to GitHub

Create a GitHub repository and upload this full `last-minute-life-saver` folder.

## 3. Create the project description Google Doc

Copy the contents of `PROJECT_DESCRIPTION.md` into a Google Doc.
Set sharing to **Anyone with the link can view**.

## 4. Submit on BlockseBlock

1. Go to https://blockseblock.com/dashboard.
2. Open the hackathon and click **Create Project**.
3. Enter a unique project name, for example `Deadline Guardian`.
4. Select **Problem Statement 1**.
5. Paste the deployed application link.
6. Paste the GitHub repository link.
7. Paste the Google Doc project description link.
8. Submit only after you have checked every link and the deployed app works.

## Final Submit Warning

The challenge instructions say the final submission cannot be modified after final submit.
Only click **Final Submit** when you are fully satisfied with the deployed app, repository, and Google Doc.

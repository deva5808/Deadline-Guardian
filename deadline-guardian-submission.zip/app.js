const state = {
  tasks: JSON.parse(localStorage.getItem("dg_tasks") || "[]"),
  habits: JSON.parse(localStorage.getItem("dg_habits") || "[]"),
  apiKey: localStorage.getItem("dg_gemini_key") || ""
};

const els = {
  tabs: document.querySelectorAll(".tab"),
  views: document.querySelectorAll(".view"),
  taskForm: document.querySelector("#taskForm"),
  taskTitle: document.querySelector("#taskTitle"),
  taskDeadline: document.querySelector("#taskDeadline"),
  taskEffort: document.querySelector("#taskEffort"),
  taskContext: document.querySelector("#taskContext"),
  taskList: document.querySelector("#taskList"),
  planTitle: document.querySelector("#planTitle"),
  planSteps: document.querySelector("#planSteps"),
  aiStatus: document.querySelector("#aiStatus"),
  nextDeadline: document.querySelector("#nextDeadline"),
  nextDeadlineDetail: document.querySelector("#nextDeadlineDetail"),
  readinessScore: document.querySelector("#readinessScore"),
  readinessBar: document.querySelector("#readinessBar"),
  urgentCount: document.querySelector("#urgentCount"),
  focusHours: document.querySelector("#focusHours"),
  habitStreak: document.querySelector("#habitStreak"),
  clearDoneBtn: document.querySelector("#clearDoneBtn"),
  habitList: document.querySelector("#habitList"),
  addHabitBtn: document.querySelector("#addHabitBtn"),
  apiKey: document.querySelector("#apiKey"),
  saveKeyBtn: document.querySelector("#saveKeyBtn"),
  exportBtn: document.querySelector("#exportBtn"),
  voiceBtn: document.querySelector("#voiceBtn")
};

const defaultHabits = [
  { id: crypto.randomUUID(), title: "Daily 15-minute planning", streak: 0, doneToday: false },
  { id: crypto.randomUUID(), title: "Inbox and calendar review", streak: 0, doneToday: false }
];

function persist() {
  localStorage.setItem("dg_tasks", JSON.stringify(state.tasks));
  localStorage.setItem("dg_habits", JSON.stringify(state.habits));
}

function hoursUntil(deadline) {
  return (new Date(deadline).getTime() - Date.now()) / 36e5;
}

function scoreTask(task) {
  const hours = Math.max(hoursUntil(task.deadline), 0.1);
  const urgency = Math.min(60, 72 / hours * 20);
  const effortPressure = Number(task.effort) * 8;
  const blockerBoost = task.context.length > 20 ? 12 : 0;
  return Math.round(Math.min(100, urgency + effortPressure + blockerBoost));
}

function riskLabel(score) {
  if (score >= 70) return ["High risk", "risk-high"];
  if (score >= 42) return ["Needs focus", "risk-medium"];
  return ["On track", ""];
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

function formatDeadline(value) {
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(value));
}

function sortTasks(tasks = state.tasks) {
  return [...tasks].sort((a, b) => scoreTask(b) - scoreTask(a));
}

function renderTasks() {
  els.taskList.innerHTML = "";
  const template = document.querySelector("#taskTemplate");
  const sorted = sortTasks();

  if (!sorted.length) {
    els.taskList.innerHTML = '<p class="task-context">No tasks yet. Add your next deadline from Mission.</p>';
    return;
  }

  sorted.forEach((task) => {
    const node = template.content.firstElementChild.cloneNode(true);
    const score = scoreTask(task);
    const [label, className] = riskLabel(score);
    node.classList.toggle("done", task.done);
    node.querySelector("h4").textContent = task.title;
    node.querySelector(".risk-pill").textContent = `${label} - ${score}`;
    if (className) node.querySelector(".risk-pill").classList.add(className);
    node.querySelector(".task-meta").textContent = `${formatDeadline(task.deadline)} - ${task.effort}h estimated`;
    node.querySelector(".task-context").textContent = task.context || "No extra context added.";
    node.querySelector(".plan-task").addEventListener("click", () => createPlan(task));
    node.querySelector(".done-task").addEventListener("click", () => {
      task.done = !task.done;
      persist();
      render();
    });
    els.taskList.appendChild(node);
  });
}

function renderHabits() {
  if (!state.habits.length) state.habits = defaultHabits;
  els.habitList.innerHTML = "";

  state.habits.forEach((habit) => {
    const row = document.createElement("article");
    row.className = "habit-row";
    row.innerHTML = `
      <div>
        <strong>${escapeHtml(habit.title)}</strong>
        <p class="task-context">${habit.streak} day streak</p>
      </div>
      <div class="habit-actions">
        <button class="secondary-btn">${habit.doneToday ? "Undo" : "Done Today"}</button>
      </div>
    `;
    row.querySelector("button").addEventListener("click", () => {
      habit.doneToday = !habit.doneToday;
      habit.streak = Math.max(0, habit.streak + (habit.doneToday ? 1 : -1));
      persist();
      render();
    });
    els.habitList.appendChild(row);
  });
}

function renderSummary() {
  const active = state.tasks.filter((task) => !task.done);
  const sortedByTime = [...active].sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
  const urgent = active.filter((task) => scoreTask(task) >= 70).length;
  const focusHours = active.reduce((sum, task) => sum + Number(task.effort), 0);
  const streak = state.habits.reduce((best, habit) => Math.max(best, habit.streak), 0);
  const readiness = Math.max(5, Math.min(98, 92 - urgent * 18 - active.length * 3 + streak * 2));

  els.urgentCount.textContent = urgent;
  els.focusHours.textContent = focusHours;
  els.habitStreak.textContent = streak;
  els.readinessScore.textContent = `${readiness}%`;
  els.readinessBar.style.width = `${readiness}%`;

  if (sortedByTime.length) {
    const next = sortedByTime[0];
    els.nextDeadline.textContent = next.title;
    els.nextDeadlineDetail.textContent = formatDeadline(next.deadline);
  } else {
    els.nextDeadline.textContent = "No active tasks";
    els.nextDeadlineDetail.textContent = "You are clear for now.";
  }
}

function localPlan(task) {
  const score = scoreTask(task);
  const hours = Math.max(1, Math.round(hoursUntil(task.deadline)));
  const minutes = Number(task.effort) <= 1 ? 25 : 45;
  return [
    `Start a ${minutes}-minute focus sprint on "${task.title}" within the next hour.`,
    `Break the work into ${Math.max(2, Number(task.effort) + 1)} checkpoints and finish the first checkpoint before any low-risk task.`,
    `Reserve ${task.effort} hour(s) before ${formatDeadline(task.deadline)} and add a 20-minute buffer for submission or travel.`,
    score >= 70
      ? `Escalate now: reduce scope, ask for help, or move conflicting work because only about ${hours} hour(s) remain.`
      : "Keep momentum: review progress at the halfway point and adjust the remaining schedule."
  ];
}

async function geminiPlan(task) {
  if (!state.apiKey) return localPlan(task);
  els.aiStatus.textContent = "Gemini planning...";
  const prompt = `Create a concise rescue plan for this task. Return exactly 4 numbered actions.
Task: ${task.title}
Deadline: ${task.deadline}
Estimated effort hours: ${task.effort}
Context/blockers: ${task.context || "none"}
Current risk score: ${scoreTask(task)}`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${state.apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.35, maxOutputTokens: 450 }
        })
      }
    );
    if (!response.ok) throw new Error("Gemini request failed");
    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const steps = text
      .split(/\n+/)
      .map((line) => line.replace(/^\d+[\).\s-]*/, "").trim())
      .filter(Boolean)
      .slice(0, 4);
    return steps.length ? steps : localPlan(task);
  } catch {
    els.aiStatus.textContent = "Gemini unavailable, local planner used";
    return localPlan(task);
  }
}

async function createPlan(task) {
  els.planTitle.textContent = task.title;
  els.planSteps.innerHTML = "<li>Building your action plan...</li>";
  const steps = await geminiPlan(task);
  els.planSteps.innerHTML = steps.map((step) => `<li>${escapeHtml(step)}</li>`).join("");
  els.aiStatus.textContent = state.apiKey ? "Gemini plan ready" : "Local planner ready";
  showView("mission");
}

function showView(id) {
  els.tabs.forEach((tab) => tab.classList.toggle("active", tab.dataset.view === id));
  els.views.forEach((view) => view.classList.toggle("active", view.id === id));
}

function exportCalendar() {
  const active = state.tasks.filter((task) => !task.done);
  if (!active.length) return;
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Deadline Guardian//Productivity Companion//EN"
  ];
  active.forEach((task) => {
    const end = new Date(task.deadline);
    const start = new Date(end.getTime() - Number(task.effort) * 36e5);
    const fmt = (date) => date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
    lines.push(
      "BEGIN:VEVENT",
      `UID:${task.id}@deadline-guardian`,
      `DTSTAMP:${fmt(new Date())}`,
      `DTSTART:${fmt(start)}`,
      `DTEND:${fmt(end)}`,
      `SUMMARY:${task.title}`,
      `DESCRIPTION:Risk score ${scoreTask(task)}. ${task.context || "Generated by Deadline Guardian."}`,
      "END:VEVENT"
    );
  });
  lines.push("END:VCALENDAR");
  const blob = new Blob([lines.join("\r\n")], { type: "text/calendar" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "deadline-guardian-calendar.ics";
  link.click();
  URL.revokeObjectURL(link.href);
}

function setupVoice() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    els.voiceBtn.disabled = true;
    els.voiceBtn.title = "Voice capture is unavailable in this browser";
    return;
  }
  const recognition = new Recognition();
  recognition.lang = "en-US";
  recognition.onresult = (event) => {
    els.taskTitle.value = event.results[0][0].transcript;
  };
  els.voiceBtn.addEventListener("click", () => recognition.start());
}

function bindEvents() {
  els.tabs.forEach((tab) => tab.addEventListener("click", () => showView(tab.dataset.view)));
  els.taskForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const task = {
      id: crypto.randomUUID(),
      title: els.taskTitle.value.trim(),
      deadline: els.taskDeadline.value,
      effort: Number(els.taskEffort.value),
      context: els.taskContext.value.trim(),
      done: false,
      createdAt: new Date().toISOString()
    };
    state.tasks.push(task);
    persist();
    els.taskForm.reset();
    render();
    await createPlan(task);
  });
  els.clearDoneBtn.addEventListener("click", () => {
    state.tasks = state.tasks.filter((task) => !task.done);
    persist();
    render();
  });
  els.addHabitBtn.addEventListener("click", () => {
    const title = prompt("Habit name");
    if (!title) return;
    state.habits.push({ id: crypto.randomUUID(), title, streak: 0, doneToday: false });
    persist();
    render();
  });
  els.saveKeyBtn.addEventListener("click", () => {
    state.apiKey = els.apiKey.value.trim();
    localStorage.setItem("dg_gemini_key", state.apiKey);
    els.aiStatus.textContent = state.apiKey ? "Gemini connected" : "Local planner ready";
  });
  els.exportBtn.addEventListener("click", exportCalendar);
}

function seedDemoDeadline() {
  const date = new Date(Date.now() + 28 * 36e5);
  date.setMinutes(0, 0, 0);
  els.taskDeadline.value = date.toISOString().slice(0, 16);
}

function render() {
  renderTasks();
  renderHabits();
  renderSummary();
}

els.apiKey.value = state.apiKey;
bindEvents();
setupVoice();
seedDemoDeadline();
render();

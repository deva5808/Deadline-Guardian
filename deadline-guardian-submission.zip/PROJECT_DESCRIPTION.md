# Deadline Guardian - Project Description

## Problem Statement Selected

Problem Statement 1: **The Last-Minute Life Saver**

## Solution Overview

Deadline Guardian is an AI-powered productivity companion for students, professionals, and entrepreneurs
who frequently miss deadlines or struggle to convert reminders into action. Instead of only reminding users,
the app analyzes each task, estimates deadline risk, prioritizes the queue, and creates a concrete rescue plan
with immediate next actions.

The product is designed for hackathon evaluation around agentic depth: it observes task context, evaluates urgency,
recommends priorities, generates plans, supports habit momentum, and helps users export planned work into a calendar.

## Key Features

- Intelligent task prioritization using deadline proximity, estimated effort, and user-provided blockers.
- AI-powered scheduling and rescue planning with Gemini.
- Context-aware recommendations that adapt to risk level.
- Voice-enabled task capture for fast commitment entry.
- Goal and habit tracking to build consistent planning behavior.
- Google Calendar compatible `.ics` export for scheduled work blocks.
- Offline/local fallback planning so the application remains functional during demos.

## Technologies Used

- HTML, CSS, and JavaScript.
- Browser Local Storage for persistent tasks, habits, and optional API key storage.
- Browser Speech Recognition API for voice capture.
- iCalendar export format for calendar integration.

## Google Technologies Utilized

- Google AI Studio for Gemini API key creation, app prototyping, and deployment workflow.
- Gemini API using `gemini-3.5-flash:generateContent` for productivity planning.
- Google Cloud Run URL generated through Google AI Studio publishing.
- Google Calendar compatible calendar export.

## Evaluation Alignment

- Problem Solving and Impact: helps users complete deadlines through prioritization and concrete action plans.
- Agentic Depth: scores risk, adapts recommendations, generates plans, and converts tasks into calendar blocks.
- Innovation and Creativity: blends task triage, voice capture, habit momentum, and calendar handoff in one focused tool.
- Usage of Google Technologies: uses Google AI Studio, Gemini API, and AI Studio deployment path.
- Product Experience and Design: offers a clean dashboard with mission, tasks, habits, and assistant views.
- Technical Implementation: lightweight, deployable, persistent browser app with graceful AI fallback.
- Completeness and Usability: runs locally, supports real tasks, and includes submission documentation.
